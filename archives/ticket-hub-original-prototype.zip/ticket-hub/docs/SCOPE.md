# Ticket Hub scope

## Product goal

Ticket Hub should cover the common core of Jira Software for small and medium development teams while remaining understandable, self-hostable, and pleasant to modify in C++. It is not intended to reproduce every Atlassian product or every Jira administration feature.

## Included in the first product line

1. Users, projects, and project membership.
2. Issues with stable project keys and sequential numbers.
3. Epic, story, task, and bug issue types.
4. Backlog, selected, in-progress, review, and done statuses.
5. Priority, reporter, assignee, description, labels, story points, due date, and parent issue.
6. Comments and issue history.
7. Search and filters.
8. Project issue list and simple Kanban board.
9. PostgreSQL as the production database.
10. SQLite as an optional embedded database.
11. REST-like JSON API and vanilla frontend.

## Explicitly excluded from the MVP

- Jira Service Management, customer portal, SLAs, queues, and incident management.
- Advanced workflow designer, validators, conditions, post-functions, and per-project workflow schemes.
- Jira Query Language compatibility. Ticket Hub will start with explicit filters and may later gain its own query language.
- Custom field designer and arbitrary field schemes.
- Marketplace plugins and Atlassian app compatibility.
- Automation rule builder.
- Portfolio/Advanced Roadmaps, capacity planning, and cross-team dependency planning.
- Confluence, Bitbucket, Bamboo, Opsgenie, or other Atlassian product clones.
- Full Scrum implementation, sprint reports, velocity charts, burn-down charts, and estimation reports in the MVP.
- Email ingestion and notification delivery in the MVP.
- Enterprise identity federation, SAML, SCIM, LDAP, and external directory synchronization in the MVP.
- Fine-grained Jira-compatible permission schemes in the MVP.

## Likely later additions

- Authentication, sessions, API tokens, roles, and permissions.
- Sprints and backlog ranking.
- Components, versions/releases, and milestones.
- Attachments with pluggable filesystem or object storage.
- Issue links, watchers, votes, and notifications.
- Saved filters and dashboards.
- WebSocket live updates.
- Audit log and administration screens.
- PostgreSQL connection pool.
- Full-text search backend abstraction.

## Deliberate product differences from Jira

- A smaller fixed core data model before introducing custom fields.
- A limited, understandable workflow model before a graphical workflow editor.
- One codebase and one deployable service.
- No frontend framework dependency.
- Database adapters are explicit C++ implementations rather than an ORM that hides transaction behavior.
