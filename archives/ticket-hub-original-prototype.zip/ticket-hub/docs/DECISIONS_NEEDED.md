# Product decisions needed before the next major phase

1. Is Ticket Hub intended for one organization per installation, or should the schema support multiple isolated organizations/tenants?
2. Which authentication method should come first: local username/password, reverse-proxy authentication, OAuth/OIDC, or something else?
3. Should the first real release focus on Kanban only, or include Scrum sprints and backlog ranking?
4. Should workflows remain globally fixed at first, or be configurable per project?
5. Are custom fields required, and if so, which initial types are essential?
6. Are permissions simple roles (`admin`, `member`, `viewer`) or Jira-like project permission schemes?
7. Should issue descriptions/comments be plain text, Markdown, or a structured rich-text document format?
8. Where should attachments live: local filesystem, S3-compatible storage, PostgreSQL large objects, or pluggable providers?
9. Is email notification required in the first deployable release?
10. Is PostgreSQL the only supported production database, with SQLite explicitly development/single-user only?
11. Is compatibility with old browsers or legacy operating systems required?
12. Which license should the actual project use? The scaffold currently contains MIT as a placeholder.
