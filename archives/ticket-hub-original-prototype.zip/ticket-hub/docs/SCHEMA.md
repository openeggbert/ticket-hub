# Logical database schema

PostgreSQL and SQLite have separate migration files but implement the same logical model. PostgreSQL is the production target. SQLite is an embedded development, demo, and test backend. IDs are application-generated UUID strings (`VARCHAR(36)` in PostgreSQL and `TEXT` in SQLite), which avoids relying on engine-specific UUID generators.

The current model is **single-tenant: one organization per installation**. A multi-tenant product would require an `organizations` table plus an `organization_id` boundary on users, projects, lookup data, authorization, unique keys, and nearly every query. This must be decided before production authentication is added.

## Migration metadata

### `schema_migrations`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `version` | string(64) | no | Primary key; migration identifier |
| `applied_at` | timestamp | no | Defaults to current timestamp |

The initial scaffold executes known migration files directly. Ordered discovery, checksums, and a cross-instance migration lock are planned.

## Identity and projects

### `users`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `username` | string(80) | no | Unique stable account key |
| `display_name` | string(160) | no | Human-readable name |
| `email` | string(320) | no | Unique email address |
| `avatar_url` | text | yes | Optional avatar location |
| `active` | boolean | no | Defaults true; soft-disable flag |
| `created_at` | timestamp | no | Creation audit time |
| `updated_at` | timestamp | no | Last update audit time |

Passwords and external identity claims are intentionally absent until the authentication decision is made.

### `projects`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `project_key` | string(10) | no | Unique; prefix for keys such as `TH-7` |
| `name` | string(160) | no | Project name |
| `description` | text | no | Defaults empty |
| `lead_user_id` | UUID string | yes | FK to `users`; `SET NULL` on user deletion |
| `next_issue_number` | 64-bit integer | no | Positive project-local counter |
| `archived` | boolean | no | Defaults false |
| `created_at` | timestamp | no | Creation audit time |
| `updated_at` | timestamp | no | Last update audit time |

Ticket creation locks the project counter and increments it in the same transaction as the issue insert. PostgreSQL uses `SELECT ... FOR UPDATE`; SQLite uses `BEGIN IMMEDIATE` and an adapter mutex.

### `project_members`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `project_id` | UUID string | no | FK to `projects`; cascade delete |
| `user_id` | UUID string | no | FK to `users`; cascade delete |
| `role_key` | string(40) | no | Defaults `member`; not enforced in MVP |
| `joined_at` | timestamp | no | Membership creation time |

Primary key: (`project_id`, `user_id`).

## Issue classification

### `issue_types`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `type_key` | string(40) | no | Unique key such as `bug` or `story` |
| `name` | string(80) | no | Display name |
| `icon` | string(40) | no | UI icon/glyph |
| `color` | string(20) | no | UI color |
| `hierarchy_level` | integer | no | Defaults 0; epic currently uses 1 |

### `issue_statuses`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `status_key` | string(40) | no | Unique key |
| `name` | string(80) | no | Display name |
| `category` | enum-like string(20) | no | `todo`, `in_progress`, or `done` |
| `sort_order` | integer | no | Stable presentation order |

The fixed category enables board grouping and basic reports even if project-specific statuses are introduced later.

### `priorities`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `priority_key` | string(40) | no | Unique key |
| `name` | string(80) | no | Display name |
| `rank` | integer | no | Lower value means higher priority |
| `color` | string(20) | no | UI color |

## Issues

### `issues`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `project_id` | UUID string | no | FK to `projects`; cascade delete |
| `issue_number` | 64-bit integer | no | Positive number unique inside project |
| `issue_key` | string(32) | no | Globally unique human key |
| `summary` | string(255) | no | Required title |
| `description` | text | no | Defaults empty |
| `issue_type_id` | UUID string | no | FK to `issue_types` |
| `status_id` | UUID string | no | FK to `issue_statuses` |
| `priority_id` | UUID string | no | FK to `priorities` |
| `reporter_user_id` | UUID string | no | FK to `users` |
| `assignee_user_id` | UUID string | yes | FK to `users`; `SET NULL` on deletion |
| `parent_issue_id` | UUID string | yes | Self-FK; `SET NULL` on parent deletion |
| `story_points` | floating point | yes | Non-negative estimate |
| `due_date` | date | yes | Optional due date |
| `resolution` | string(80) | yes | Future resolution semantics |
| `created_at` | timestamp | no | Creation audit time |
| `updated_at` | timestamp | no | Last update audit time |

Unique constraints: `issue_key`; (`project_id`, `issue_number`). Indexes cover project, status, assignee, and descending update time. A future production phase should add a revision/version column for optimistic concurrency and a soft-delete/archive policy.

## Labels and collaboration

### `labels`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `name` | string(64) | no | Globally unique label name |
| `color` | string(20) | no | Defaults neutral gray |

### `issue_labels`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `issue_id` | UUID string | no | FK to `issues`; cascade delete |
| `label_id` | UUID string | no | FK to `labels`; cascade delete |

Primary key: (`issue_id`, `label_id`).

### `comments`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `issue_id` | UUID string | no | FK to `issues`; cascade delete |
| `author_user_id` | UUID string | no | FK to `users` |
| `body` | text | no | Comment text |
| `created_at` | timestamp | no | Creation audit time |
| `updated_at` | timestamp | no | Edit audit time |

Index: (`issue_id`, `created_at`). Comment editing/deletion policy is not yet implemented.

### `issue_history`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `issue_id` | UUID string | no | FK to `issues`; cascade delete |
| `actor_user_id` | UUID string | yes | FK to `users`; `SET NULL` on deletion |
| `field_name` | string(80) | no | Changed field identifier |
| `old_value` | text | yes | Previous serialized value |
| `new_value` | text | yes | New serialized value |
| `created_at` | timestamp | no | Change time |

The MVP records status changes. Full issue editing should write all mutations through the same history mechanism.

## Links and attachments reserved for later API/UI

### `issue_links`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `source_issue_id` | UUID string | no | FK to `issues`; cascade delete |
| `target_issue_id` | UUID string | no | FK to `issues`; cascade delete |
| `link_type` | string(40) | no | For example `blocks`, `duplicates`, `relates` |
| `created_at` | timestamp | no | Link creation time |

Constraint: source and target cannot be the same issue. A later migration should add the chosen uniqueness rule and link-type catalog.

### `attachments`

| Column | Logical type | Null | Constraints / purpose |
|---|---|---:|---|
| `id` | UUID string | no | Primary key |
| `issue_id` | UUID string | no | FK to `issues`; cascade delete |
| `uploader_user_id` | UUID string | no | FK to `users` |
| `file_name` | string(255) | no | Original display name |
| `content_type` | string(160) | no | Declared media type |
| `byte_size` | 64-bit integer | no | Non-negative size |
| `storage_key` | text | no | Unique key in a pluggable storage provider |
| `created_at` | timestamp | no | Upload time |

Only metadata belongs in the database. File bytes should be handled by a storage interface with local-filesystem and S3-compatible implementations.

## Deliberately deferred tables

These should be added only in a product phase that defines their semantics: organizations/tenants, credentials and external identities, sessions, API tokens, roles and permissions, boards, board columns, issue rank, sprints, sprint membership, components, versions/releases, watchers, notifications, saved filters, webhooks, durable background jobs, custom-field definitions, and custom-field values.
