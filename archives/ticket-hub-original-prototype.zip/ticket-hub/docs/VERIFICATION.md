# Verification status

Verification performed in the generation environment on 2026-07-29:

- CMake 3.31.6 configured the core-only build successfully.
- GCC 14.2 compiled `ticket-hub-core` with both database implementations enabled.
- SQLite adapter compiled and linked against SQLite 3.46.1.
- PostgreSQL adapter compiled and linked against libpq 17.9.
- Domain validation test passed.
- SQLite integration test passed. It applies the schema, applies the demo seed twice, lists projects and issues, creates `TH-7`, reads it back, changes it to Done, records a comment, and validates dashboard totals/order.
- `node --check web/app.js` passed with Node.js 22.16.0.

Not verified in this environment:

- The final Crow HTTP executable could not be compiled here because the sandbox shell could not resolve GitHub to fetch Crow. The project pins Crow v1.3.3, first tries an installed `Crow::Crow` CMake package, includes a vcpkg manifest, and supports core-only builds so this network limitation does not block database/domain verification.
- PostgreSQL runtime migrations and API operations were not exercised because no PostgreSQL server/client executable was available. The adapter itself was compiled against libpq and uses parameterized calls and explicit transactions.
- Browser end-to-end behavior has not yet been automated.

The repository is an MVP foundation, not production-ready software. Authentication, authorization, CSRF protection, migration checksums/locking, pagination, connection pooling, attachment security, and production deployment hardening remain planned work.
