#include "infrastructure/database/SqliteDatabase.h"

#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>

#ifndef TICKETHUB_SOURCE_DIR
#define TICKETHUB_SOURCE_DIR "."
#endif

namespace {

void require(const bool condition, const std::string& message) {
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(1);
    }
}

} // namespace

int main() {
    namespace fs = std::filesystem;
    using TicketHub::Domain::CreateIssueRequest;
    using TicketHub::Domain::IssueFilter;
    using TicketHub::Infrastructure::Database::SqliteDatabase;

    const fs::path sourceRoot(TICKETHUB_SOURCE_DIR);
    const fs::path databasePath = fs::temp_directory_path() / "ticket-hub-integration.db";
    std::error_code removeError;
    fs::remove(databasePath, removeError);
    fs::remove(databasePath.string() + "-wal", removeError);
    fs::remove(databasePath.string() + "-shm", removeError);

    {
        SqliteDatabase database(
            databasePath.string(),
            (sourceRoot / "migrations/sqlite/001_initial.sql").string(),
            (sourceRoot / "migrations/sqlite/002_seed_demo.sql").string());

        database.migrate();
        database.seedDemoData();
        database.seedDemoData();

        const auto projects = database.listProjects();
        require(projects.size() == 2, "demo seed creates two projects and is idempotent");

        const auto initialIssues = database.listIssues(IssueFilter{});
        require(initialIssues.size() == 8, "demo seed creates eight issues");

        CreateIssueRequest request;
        request.projectKey = "TH";
        request.summary = "Verify portable database architecture";
        request.description = "Created by the SQLite integration test.";
        request.issueTypeKey = "task";
        request.priorityKey = "high";
        request.assigneeUsername = "alex";
        request.labels = {"database", "integration"};
        request.storyPoints = 3.0;

        const auto created = database.createIssue(request, "demo");
        require(created.key == "TH-7", "project-local issue counter creates TH-7");
        require(created.labels.size() == 2, "created issue has both labels");

        const auto found = database.findIssueByKey(created.key);
        require(found.has_value() && found->summary == request.summary, "created issue can be read back");

        require(database.changeIssueStatus(created.key, "done", "demo"), "issue status can be changed");
        const auto done = database.findIssueByKey(created.key);
        require(done.has_value() && done->status.key == "done", "changed status is persisted");

        const auto comment = database.addComment({created.key, "Database adapter smoke test passed."}, "demo");
        require(!comment.id.empty(), "comment receives an id");
        require(database.listComments(created.key).size() == 1, "comment can be listed");

        const auto dashboard = database.dashboardStats();
        require(dashboard.totalIssues == 9, "dashboard includes newly created issue");
        require(!dashboard.recentIssues.empty() && dashboard.recentIssues.front().key == created.key,
                "dashboard returns the most recently updated issue first");
    }

    fs::remove(databasePath, removeError);
    fs::remove(databasePath.string() + "-wal", removeError);
    fs::remove(databasePath.string() + "-shm", removeError);

    std::cout << "SQLite integration tests passed\n";
    return 0;
}
