#include "domain/Validation.h"

#include <cstdlib>
#include <iostream>
#include <string>

namespace {

void require(bool condition, const std::string& message) {
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
        std::exit(1);
    }
}

} // namespace

int main() {
    using namespace TicketHub::Domain;

    require(normalizeProjectKey(" ticket-hub ") == "TICKETHUB", "project key normalization");
    require(normalizeProjectKey("th_2") == "TH2", "project key strips punctuation");

    CreateIssueRequest valid;
    valid.projectKey = "TH";
    valid.summary = "Create an issue";
    require(validateCreateIssue(valid).empty(), "valid issue request");

    CreateIssueRequest invalid;
    invalid.projectKey = "1";
    invalid.summary = "";
    invalid.storyPoints = -1.0;
    const auto errors = validateCreateIssue(invalid);
    require(errors.size() == 3, "invalid request reports all expected errors");

    std::cout << "All domain validation tests passed\n";
    return 0;
}
