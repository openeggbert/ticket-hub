# Ticket Hub development plan

## Phase 0 — foundation (implemented in this scaffold)

- [x] CMake C++20 project.
- [x] Main namespace `TicketHub`.
- [x] Crow HTTP server.
- [x] Vanilla HTML/CSS/JS frontend.
- [x] Database interface at domain-operation level.
- [x] PostgreSQL adapter using libpq parameters and transactions.
- [x] SQLite adapter using prepared statements and explicit transactions.
- [x] Initial cross-backend logical schema.
- [x] Idempotent demo data.
- [x] Project list, issue list, dashboard, board, issue detail, status update, comments, and issue creation.
- [x] Basic input validation.
- [x] Domain unit test and SQLite adapter integration test.
- [x] Core-only build mode independent of the Crow download.
- [x] Docker Compose PostgreSQL service.
- [x] Initial documentation and scope boundaries.

## Phase 1 — production-safe identity and authorization

- [ ] Decide single-tenant versus multi-tenant architecture.
- [ ] Add password hashing library and secure local login, or implement chosen OIDC/reverse-proxy mode.
- [ ] Add sessions with secure, HTTP-only, SameSite cookies.
- [ ] Add CSRF protection for cookie-authenticated writes.
- [ ] Add logout, session expiry, and session revocation.
- [ ] Add roles and explicit authorization checks in the application layer.
- [ ] Replace fixed demo user with authenticated request context.
- [ ] Add account and project-member administration screens.
- [ ] Add rate limiting for authentication and write endpoints.
- [ ] Add security headers and configurable trusted proxy handling.
- [ ] Add audit records for security-sensitive operations.

## Phase 2 — migrations and persistence quality

- [ ] Replace single-file startup migration with ordered migration discovery.
- [ ] Store checksums and refuse changed historical migrations.
- [ ] Add migration lock to prevent multiple instances migrating concurrently.
- [ ] Add PostgreSQL connection pool with bounded size and health checks.
- [ ] Add SQLite single-process limitations to documentation and runtime diagnostics.
- [ ] Add transaction helper abstractions without hiding backend semantics.
- [x] Add SQLite database integration test.
- [ ] Add PostgreSQL database integration test.
- [ ] Add backup/restore documentation.
- [ ] Add pagination primitives to database methods and API responses.
- [ ] Add optimistic concurrency/version column for issue updates.

## Phase 3 — complete issue editing

- [ ] Edit summary, description, type, priority, assignee, reporter, story points, due date, and labels.
- [ ] Write history entries for all changed fields.
- [ ] Add parent/subtask behavior and hierarchy validation.
- [ ] Add issue deletion policy: soft delete, archive, or permanent delete.
- [ ] Add bulk update operations.
- [ ] Add watchers.
- [ ] Add issue links API and UI.
- [ ] Add attachment storage provider interface.
- [ ] Implement local filesystem attachment provider.
- [ ] Add attachment size/type limits and safe download headers.
- [ ] Add issue activity timeline combining comments and field history.

## Phase 4 — board and backlog

- [ ] Persist boards instead of deriving one fixed board from statuses.
- [ ] Add configurable board columns mapped to statuses.
- [ ] Add issue rank using fractional/lexicographic ranking.
- [ ] Add drag-and-drop with accessible keyboard alternative.
- [ ] Add backlog view.
- [ ] Decide and implement Kanban-only or Scrum sprint model.
- [ ] Add sprint creation/start/complete if Scrum is selected.
- [ ] Add board filters and saved board configuration.
- [ ] Add WIP limits if desired.
- [ ] Add WebSocket or polling-based live board updates.

## Phase 5 — search and filters

- [ ] Define stable filter request model.
- [ ] Add pagination, sorting, and multiple values per filter.
- [ ] Add created/updated/due-date ranges.
- [ ] Add reporter, assignee, priority, type, label, and project filters.
- [ ] Add PostgreSQL full-text search implementation.
- [ ] Add SQLite FTS5 implementation where available.
- [ ] Keep search behind a backend interface.
- [ ] Add saved filters and sharing permissions.
- [ ] Decide whether Ticket Hub needs a query language.
- [ ] Add search performance tests and indexes.

## Phase 6 — project configuration

- [ ] Project create/edit/archive screens.
- [ ] Project member management.
- [ ] Components.
- [ ] Versions/releases.
- [ ] Configurable issue types per project.
- [ ] Decide workflow configurability level.
- [ ] Add status/workflow administration only after the model is settled.
- [ ] Project-specific defaults.
- [ ] Project roles and permissions.
- [ ] Import/export project configuration.

## Phase 7 — notifications and integrations

- [ ] Internal notification table and unread state.
- [ ] Notification preference model.
- [ ] Email provider interface.
- [ ] SMTP implementation.
- [ ] Background job runner with durable jobs.
- [ ] Webhook subscriptions with signing and retry policy.
- [ ] API tokens/scopes.
- [ ] OpenAPI document.
- [ ] Git commit/branch links only after core product stability.
- [ ] Optional inbound email only if required.

## Phase 8 — quality, operations, and deployment

- [ ] Unit tests for service validation and authorization.
- [ ] PostgreSQL and SQLite integration test suites.
- [ ] HTTP API tests.
- [ ] Browser end-to-end tests.
- [ ] Sanitizer CI.
- [ ] Static analysis and formatting CI.
- [ ] Container image with non-root user and read-only root filesystem support.
- [ ] Health, readiness, and metrics endpoints.
- [ ] Structured logs and request correlation IDs.
- [ ] Graceful shutdown and connection draining.
- [ ] Configuration validation at startup.
- [ ] Production reverse-proxy example.
- [ ] Backup/restore and upgrade runbook.
- [ ] Accessibility review.
- [ ] Threat model and security review.

## Phase 9 — optional advanced features

- [ ] Dashboards and gadgets.
- [ ] Custom fields with a deliberately limited type set.
- [ ] Automation rules only after a safe permission model exists.
- [ ] Time tracking.
- [ ] Votes.
- [ ] Release reports.
- [ ] Burn-down/velocity reports if Scrum is included.
- [ ] Data importers for CSV and selected Jira exports.
- [ ] Localization.
- [ ] Theme support.
- [ ] Plugin architecture only if real extension requirements justify it.
