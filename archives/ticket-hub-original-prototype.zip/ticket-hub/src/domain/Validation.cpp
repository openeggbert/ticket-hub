#include "domain/Validation.h"

#include <algorithm>
#include <cctype>
#include <regex>

namespace TicketHub::Domain {

std::string normalizeProjectKey(const std::string& value) {
    std::string result;
    result.reserve(value.size());
    for (const unsigned char ch : value) {
        if (std::isalnum(ch) != 0) {
            result.push_back(static_cast<char>(std::toupper(ch)));
        }
    }
    return result;
}

std::vector<std::string> validateCreateIssue(const CreateIssueRequest& request) {
    std::vector<std::string> errors;
    const auto normalizedKey = normalizeProjectKey(request.projectKey);
    static const std::regex projectKeyPattern("^[A-Z][A-Z0-9]{1,9}$");

    if (!std::regex_match(normalizedKey, projectKeyPattern)) {
        errors.emplace_back("projectKey must contain 2-10 uppercase letters or digits and start with a letter");
    }
    if (request.summary.empty()) {
        errors.emplace_back("summary is required");
    } else if (request.summary.size() > 255) {
        errors.emplace_back("summary must not exceed 255 characters");
    }
    if (request.description.size() > 100000) {
        errors.emplace_back("description must not exceed 100000 characters");
    }
    if (request.issueTypeKey.empty()) {
        errors.emplace_back("issueTypeKey is required");
    }
    if (request.priorityKey.empty()) {
        errors.emplace_back("priorityKey is required");
    }
    if (request.storyPoints.has_value() && (*request.storyPoints < 0.0 || *request.storyPoints > 10000.0)) {
        errors.emplace_back("storyPoints must be between 0 and 10000");
    }
    if (request.labels.size() > 50) {
        errors.emplace_back("an issue may have at most 50 labels");
    }
    if (std::any_of(request.labels.begin(), request.labels.end(), [](const std::string& label) {
            return label.empty() || label.size() > 64;
        })) {
        errors.emplace_back("labels must contain 1-64 characters");
    }

    return errors;
}

} // namespace TicketHub::Domain
